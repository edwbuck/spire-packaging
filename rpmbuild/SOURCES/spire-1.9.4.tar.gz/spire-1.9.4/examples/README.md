# Examples have been moved

The examples that lived here have moved to a dedicated repository. Please visit <https://github.com/spiffe/spire-examples> for maintained SPIRE integration and deployment examples.
