# Server plugin: KeyManager "memory"

The `memory` key manager creates and maintains a set of private keys held
only in memory.

It has no configuration.
