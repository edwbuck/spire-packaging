<!--
If you are looking for help, please join us on [Slack or the mailing
lists.](https://github.com/spiffe/spiffe/blob/master/README.md)

If you are submitting a feature request or bug report, please be
as detailed as possible.
-->

* **Version**: <!-- version or commit hash -->
* **Platform**: <!-- `uname -a` -->
* **Subsystem**: <!-- server, agent or plugin name -->
